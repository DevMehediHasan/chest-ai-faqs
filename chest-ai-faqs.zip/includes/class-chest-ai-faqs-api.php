<?php

class ChestAIFaqs_API {

    private $db;

    public function __construct($db) {
        $this->db = $db;
        add_action('rest_api_init', [$this, 'register_api_routes']);
    }

    // Register custom REST API routes
    public function register_api_routes() {
        register_rest_route('chest-ai-faqs/v1', '/all', [
            'methods' => 'GET',
            'callback' => [$this, 'get_all_faqs'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('chest-ai-faqs/v1', '/home', [
            'methods' => 'GET',
            'callback' => [$this, 'get_home_faqs'],
            'permission_callback' => '__return_true',
        ]);
    }

    // Fetch all FAQs
    public function get_all_faqs() {
        return $this->db->get_all_faqs();
    }

    // Fetch FAQs for Home Page
    public function get_home_faqs() {
        return $this->db->get_home_faqs();
    }
}
